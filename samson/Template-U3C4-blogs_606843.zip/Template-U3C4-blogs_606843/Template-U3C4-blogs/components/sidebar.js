function sidebar() {
  // return your html component here
  //Make sure to give input search box id as "searchbar"
  return `<h2>Blog Search</h2>
  <div>Login</div>
  <input type="text" placeholder="Search blog" id="searchbar"/>
  <div>startup</div>
  <div>blogletters</div>
  <div>Audio</div>
  <div>Video</div>`
}
export default sidebar;
